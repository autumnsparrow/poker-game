/**
 * @sparrow
 * @5:17:55 PM
 * @coptyright Beijing BZWT Technology Co ., Ltd .
 */
package com.sky.game.context.id;

/**
 * @author sparrow
 *
 */
public interface IGlobalIdGenerator {
	
	public Long getId(int type);

}
