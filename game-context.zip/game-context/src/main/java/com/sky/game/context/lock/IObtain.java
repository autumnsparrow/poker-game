package com.sky.game.context.lock;

public interface IObtain<T,A> {
	
	public  T obtain(A a);

}
