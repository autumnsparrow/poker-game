/**
 * 
 */
package com.sky.game.context.spring;

/**
 * @author sparrow
 *
 */
public interface IRemoteService {

}
