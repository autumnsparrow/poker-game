/**
 * 
 */
package com.sky.game.context.json;

/**
 * @author sparrow
 *
 */
public enum HandlerObjectType {
	Request,
	Response,
	Extra

}
