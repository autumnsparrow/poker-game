package com.sky.game.context;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        
//        Pattern p=Pattern.compile("GC[0-9][0-9][0-9][0-9]");
//        Matcher m=p.matcher("GC0001");
//        if(m.find()){
//        	System.out.print("Match found");
//        }
        
        
    }
}
