package com.sky.game.context.game;

public class GameDoOnTurnException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3738082000363685105L;

	public GameDoOnTurnException() {
		// TODO Auto-generated constructor stub
	}

	public GameDoOnTurnException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public GameDoOnTurnException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public GameDoOnTurnException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	

}
